from errorpos import *


class Lexical_Analyser:
    def __init__(self, file_name, text):
        self.file_name = file_name
        self.text = text
        self.pos = Position(-1, 0, -1, file_name, text)
        self.current_char = None
        self.next()

    def next(self):
        self.pos.next(self.current_char)
        self.current_char = self.text[self.pos.index] if self.pos.index < len(self.text) else None

    @property
    def token_generator(self):
        tokens = []

        while self.current_char is not None:
            # Ignoring the characters such as spaces and tabs
            if self.current_char in ' \t':
                self.next()
            # Ignoring the characters which starts with #
            elif self.current_char == '#':
                self.comments()
            # Creating Function for Digits
            elif self.current_char in DIGITS:
                tokens.append(self.number_generation())
            # Creating Function for Letters
            elif self.current_char in LETTERS:
                tokens.append(self.identifier_generation())
            # Creating Function for String "which are written in double inverted comma's"
            elif self.current_char == '"':
                tokens.append(self.string_generation())
            # Creating Function for String 'which are written in inverted comma's'
            elif self.current_char == "'":
                tokens.append(self.string_generation())
            # Creating Function for Nextline character
            elif self.current_char == '\n':
                tokens.append(Tokens(Tokentype_NEWLINE, pos_start=self.pos))

            elif self.current_char == '+':
                tokens.append(Tokens(Tokentype_PLUS, pos_start=self.pos))
                self.next()

            elif self.current_char == '-':
                tokens.append(Tokens(Tokentype_MINUS, pos_start=self.pos))
                self.next()

            elif self.current_char == '*':
                tokens.append(Tokens(Tokentype_MUL, pos_start=self.pos))
                self.next()

            elif self.current_char == '/':
                tokens.append(Tokens(Tokentype_DIV, pos_start=self.pos))
                self.next()

            elif self.current_char == '(':
                tokens.append(Tokens(Tokentype_LPAREN, pos_start=self.pos))
                self.next()

            elif self.current_char == ')':
                tokens.append(Tokens(Tokentype_RPAREN, pos_start=self.pos))
                self.next()

            elif self.current_char == '[':
                tokens.append(Tokens(Tokentype_LSQUARE))
                self.next()

            elif self.current_char == ']':
                tokens.append(Tokens(Tokentype_RSQUARE))
                self.next()

            elif self.current_char == '{':
                tokens.append(Tokens(Tokentype_LCURLY))
                self.next()

            elif self.current_char == '}':
                tokens.append(Tokens(Tokentype_RCURLY))
                self.next()

            elif self.current_char == '^':
                tokens.append(Tokens(Tokentype_BITWISE_XOR))
                self.next()

            elif self.current_char == '!':
                token, error = self.not_equals_generation()
                if error: return [], error
                tokens.append(token)

            elif self.current_char == '=':
                tokens.append(self.equals_generation())

            elif self.current_char == '<':
                tokens.append(self.less_than_generation())

            elif self.current_char == '>':
                tokens.append(self.greater_than_generation())

            elif self.current_char == ',':
                tokens.append(Tokens(Tokentype_COMMA, self.current_char))
                self.next()

            elif self.current_char == ':':
                tokens.append(Tokens(Tokentype_COLON, self.current_char))
                self.next()

            elif self.current_char == ';':
                tokens.append(Tokens(Tokentype_SEMICOLON, self.current_char))
                self.next()

            elif self.current_char == '&':
                tokens.append(self.and_log_bit())

            elif self.current_char == '|':
                tokens.append(self.or_log_bit())

            elif self.current_char == '%':
                tokens.append(Tokens(Tokentype_MODULO))
                self.next()

            else:
                pos_first = self.pos.copy()
                char = self.current_char
                self.next()
                return [], IllegalCharError(pos_first, self.pos, "'" + char + "'")

        tokens.append(Tokens(Tokentype_EOL))
        return tokens, None

    def comments(self):
        while self.current_char is not None and self.current_char != '\n':
            self.next()

    def number_generation(self):
        num_str = ''
        dot_count = 0
        pos_start = self.pos.copy()

        while self.current_char is not None and self.current_char in DIGITS + '.':
            if self.current_char == '.':
                if dot_count == 1:
                    break
                dot_count += 1
                num_str += '.'
            else:
                num_str += self.current_char
            self.next()

        if dot_count == 0:
            return Tokens(Tokens(Tokentype_INTEGER), int(num_str), pos_start, self.pos)
        else:
            return Tokens(Tokens(Tokentype_FLOAT), float(num_str), pos_start, self.pos)

    def identifier_generation(self):
        identifier_str = ''

        while self.current_char is not None and (self.current_char.isalnum() or self.current_char == '_'):
            identifier_str += self.current_char
            self.next()

        if identifier_str.lower() == 'true':
            return Tokens(Tokentype_BOOLEAN, True)
        elif identifier_str.lower() == 'false':
            return Tokens(Tokentype_BOOLEAN, 'False')
        elif identifier_str in KEYWORDS:
            token_type = Tokentype_KEYWORD if identifier_str in KEYWORDS else Tokentype_IDENTIFIER
            return Tokens(token_type, identifier_str)
        else:
            return Tokens(Tokentype_IDENTIFIER, identifier_str)

    def string_generation(self):
        string = ''
        pos_start = self.pos.copy()
        escape_character = False
        self.next()

        escape_characters = {
            'n': '\n',
            't': '\t'
        }

        while self.current_char is not None and (self.current_char != '"' or escape_character):
            if escape_character:
                string += escape_characters.get(self.current_char, self.current_char)
            else:
                if self.current_char == '\\':
                    escape_character = True
                else:
                    string += self.current_char
            self.next()
            escape_character = False

        self.next()
        return Tokens(Tokentype_STRING, string, pos_start, self.pos)

    def not_equals_generation(self):
        start_pos = self.pos.copy()

        self.next()

        if self.current_char == '=':
            self.next()
            return Tokens(Tokentype_NOTEQUALS), None
        else:
            return None, Error.ExpectedCharError(start_pos, self.pos, 'Expected "=" after "!"')

    def equals_generation(self):
        self.next()
        if self.current_char == '=':
            self.next()
            return Tokens(Tokentype_EE)
        else:
            return Tokens(Tokentype_EQUALS)

    def less_than_generation(self):
        self.next()
        if self.current_char == '<':
            self.next()
            return Tokens(Tokentype_LEFT_SHIFT)
        elif self.current_char == '=':
            self.next()
            return Tokens(Tokentype_LE)
        else:
            return Tokens(Tokentype_LESS)

    def greater_than_generation(self):
        self.next()
        if self.current_char == '>':
            self.next()
            return Tokens(Tokentype_RIGHT_SHIFT)
        elif self.current_char == '=':
            self.next()
            return Tokens(Tokentype_GE)
        else:
            return Tokens(Tokentype_GREATER)

    def and_log_bit(self):
        self.next()
        if self.current_char == '&':
            self.next()
            return Tokens(Tokentype_LOGICAL_AND)
        else:
            return Tokens(Tokentype_BITWISE_AND)

    def or_log_bit(self):
        self.next()
        if self.current_char == '|':
            self.next()
            return Tokens(Tokentype_LOGICAL_OR)
        else:
            return Tokens(Tokentype_BITWISE_OR)

    def increment_generation(self):
        self.next()
        if self.current_char == '+':
            self.next()
            return Tokens(Tokentype_INC)
        elif self.current_char == '=':
            self.next()
            return Tokens(Tokentype_ADD_ASSIGN)
        else:
            return Tokens(Tokentype_PLUS)

    def decrement_generation(self):
        self.next()
        if self.current_char == '-':
            self.next()
            return Tokens(Tokentype_DRC)
        elif self.current_char == '=':
            self.next()
            return Tokens(Tokentype_MIN_ASSIGN)
        else:
            return Tokens(Tokentype_MINUS)

    def Exponent_generation(self):
        self.next()
        if self.current_char == '*':
            self.next()
            return Tokens(Tokentype_EXPO)
        elif self.current_char == '=':
            self.next()
            return Tokens(Tokentype_MUL_ASSIGN)
        else:
            return Tokens(Tokentype_MUL)

    def divide_assigment_generation(self):
        self.next()
        if self.current_char == '=':
            self.next()
            return Tokens(Tokentype_DIV_ASSIGN)
        else:
            return Tokens(Tokentype_DIV)


class Tokens:

    def __init__(self, type_, value=None, pos_start=None, pos_end=None):
        self.type = type_
        self.value = value

        if pos_start:
            self.pos_start = pos_start.copy()
            self.pos_end = pos_start.copy()
            self.pos_end.next()

        if pos_end:
            self.pos_end = pos_end

    def matches(self, type_, value):
        return self.type == type_ and self.value == value

    def __repr__(self):
        if self.value:
            return f'{self.type}: {self.value}'
        return f'{self.type}'


# POSITION
class Position:
    def __init__(self, index, line_number, column_number, file_name, file_text):
        self.index = index
        self.line_number = line_number
        self.column_number = column_number
        self.file_name = file_name
        self.file_text = file_text

    def next(self, current_char=None):
        self.index += 1
        self.column_number += 1

        if current_char == '\n':
            self.line_number += 1
            self.column_number += 0

        return self

    def copy(self):
        return Position(self.index, self.line_number, self.column_number, self.file_name, self.file_text)


# ERRORS
class Error:
    def __init__(self, pos_start, pos_end, error_name, details):
        self.pos_start = pos_start
        self.pos_end = pos_end
        self.error_name = error_name
        self.details = details

    def as_string(self):
        result = f'{self.error_name}: {self.details}'
        result += f'File {self.pos_start.file_name}, line {self.pos_start.line_number + 1}'
        result += '\n\n' + errorpos(self.pos_start.file_text, self.pos_start, self.pos_end)
        return result

    @classmethod
    def ExpectedCharError(cls, start_pos, pos, details):
        return cls(start_pos, pos, 'Expected Character', details)


class IllegalCharError(Error):
    def __init__(self, pos_start, pos_end, details):
        super().__init__(pos_start, pos_end, 'Illegal Character', details)


class InvalidSyntaxError(Error):
    def __init__(self, pos_start, pos_end, details):
        super().__init__(pos_start, pos_end, 'Invalid Syntax', details)


class RTError(Error):
    def __init__(self, pos_start, pos_end, details, context):
        super().__init__(pos_start, pos_end, 'Runtime Error', details)
        self.context = context

    def as_string(self):
        result = self.generate_traceback()
        result += f'{self.error_name}: {self.details}'
        result += '\n\n' + errorpos(self.pos_start.file_text, self.pos_start, self.pos_end)
        return result

    def generate_traceback(self):
        result = ''
        pos = self.pos_start
        ctx = self.context

        while ctx:
            result = f'  File {pos.fn}, line {str(pos.ln + 1)}, in {ctx.display_name}\n' + result
            pos = ctx.parent_entry_pos
            ctx = ctx.parent

        return 'Traceback (most recent call last):\n' + result


# Nodes
class Node:
    def __init__(self, tk):
        self.tk = tk

    def __repr__(self):
        return f'{self.tk}'


class VarAccessNode:
    def __init__(self, var_name_tok):
        self.var_name_tok = var_name_tok

        self.pos_start = self.var_name_tok.pos_start
        self.pos_end = self.var_name_tok.pos_end


class VarAssignNode:
    def __init__(self, var_name_tok, value_node):
        self.var_name_tok = var_name_tok
        self.value_node = value_node

        self.pos_start = self.var_name_tok.pos_start
        self.pos_end = self.value_node.pos_end


class OPRNodes:
    def __init__(self, l_node, op_tk, r_node):
        self.l_node = l_node
        self.r_node = r_node
        self.op_tk = op_tk

    def __repr__(self):
        return f'({self.l_node}, {self.op_tk}, {self.r_node})'


class UnaryOpNode:
    def __init__(self, op_tok, node):
        self.op_tok = op_tok
        self.node = node

    def __repr__(self):
        return f'({self.op_tok}, {self.node})'


class ParseResult:
    def __init__(self):
        self.error = None
        self.node = None
        self.advance_count = 0

    def register_advancement(self):
        self.advance_count += 1

    def store(self, res):
        if isinstance(res, ParseResult):
            if res.error:
                self.error = res.error
            return res.node
        return res

    def passed(self, node):
        self.node = node
        return self

    def fail(self, error):
        self.error = error
        return self


class Parser:
    def __init__(self, token):
        print(token)
        self.token = token
        self.tk_idx = 0
        self.advance()

    def advance(self):
        self.tk_idx += 1
        if self.tk_idx < len(self.token):
            self.curr_tk = self.token[self.tk_idx]
        else:
            self.curr_tk = Tokens(None)
        return self.curr_tk

    def parse(self):
        res = self.exp()
        if not res.error and self.curr_tk.type != Tokentype_EOL:
            return res.fail(InvalidSyntaxError(
                self.curr_tk.pos_start, self.curr_tk.pos_end,
                "Expected '+', '-', '*', '/', '^', '==', '!=', '<', '>', <=', '>=', 'AND' or 'OR'"
            ))
        return res

    def atom(self):
        res = ParseResult()
        tok = self.curr_tk

        if tok.type in (Tokentype_INTEGER, Tokentype_FLOAT):
            res.register_advancement()
            self.advance()
            return res.passed(Node(tok))

        elif tok.type == Tokentype_IDENTIFIER:
            res.register_advancement()
            self.advance()
            return res.passed(VarAccessNode(tok))

        elif tok.type == Tokentype_LPAREN:
            res.register_advancement()
            self.advance()
            expr = res.store(self.exp())
            if res.error:
                return res
            if self.curr_tk.type == Tokentype_RPAREN:
                res.register_advancement()
                self.advance()
                return res.passed(expr)
            else:
                return res.fail(InvalidSyntaxError(
                    self.curr_tk.pos_start, self.curr_tk.pos_end,
                    "Expected ')'"
                ))

        return res.fail(InvalidSyntaxError(
            tok.pos_start, tok.pos_end,
            "Expected int, float, identifier, '+', '-' or '('"
        ))

    def power(self):
        return self.opr(self.atom, (Tokentype_POW,), self.factor)

    def factor(self):
        res = ParseResult()
        tk = self.curr_tk

        if tk.type in (Tokentype_PLUS, Tokentype_MINUS):
            res.store(self.advance())
            factor = res.store(self.factor())
            return res.passed(OPRNodes(None, tk, factor))

        elif tk.type in (Tokentype_INTEGER, Tokentype_FLOAT):
            res.store(self.advance())
            return res.passed(Node(tk))

        elif tk.type == Tokentype_LPAREN:
            res.passed(self.advance())
            expr = res.passed(self.exp())
            if res.error:
                return res
            if self.curr_tk.type == Tokentype_RPAREN:
                res.passed(self.advance())
                return res.passed(expr)
            else:
                return res.fail(InvalidSyntaxError(
                    self.curr_tk.pos_start, self.curr_tk.pos_end,
                    "Expected ')'"
                ))

        return res.fail(InvalidSyntaxError(tk.pos_start, tk.pos_end, "Expected int or float, '+', '-', or '('"))

    def term(self):
        return self.opr(self.factor, (Tokentype_MUL, Tokentype_DIV))

    def exp(self):
        res = ParseResult()

        if self.curr_tk.matches(Tokentype_KEYWORD, 'VAR'):
            res.register_advancement()
            self.advance()

            if self.curr_tk.type != Tokentype_IDENTIFIER:
                return res.fail(InvalidSyntaxError(
                    self.curr_tk.pos_start, self.curr_tk.pos_end,
                    "Expected identifier"
                ))

            var_name = self.curr_tk
            res.register_advancement()
            self.advance()

            if self.curr_tk.type != Tokentype_EQUALS:
                return res.fail(InvalidSyntaxError(
                    self.curr_tk.pos_start, self.curr_tk.pos_end,
                    "Expected '='"
                ))

            res.register_advancement()
            self.advance()
            expr = res.store(self.exp())
            if res.error:
                return res
            return res.passed(VarAssignNode(var_name, expr))

        node = res.store(self.opr(self.comp_expr, ((Tokentype_KEYWORD, 'AND'), (Tokentype_KEYWORD, 'OR'))))

        if res.error:
            return res.fail(InvalidSyntaxError(
                self.curr_tk.pos_start, self.curr_tk.pos_end,
                "Expected 'VAR', int, float, identifier, '+', '-', '(' or 'NOT'"
            ))

        return res.passed(node)

    def arith_expr(self):
        return self.opr(self.term, (Tokentype_PLUS, Tokentype_MINUS))

    def comp_expr(self):
        res = ParseResult()

        if self.curr_tk.matches(Tokentype_KEYWORD, 'NOT'):
            op_tok = self.curr_tk
            res.register_advancement()
            self.advance()

            node = res.store(self.comp_expr())
            if res.error:
                return res
            return res.passed(UnaryOpNode(op_tok, node))

        node = res.store(self.opr(self.arith_expr, (Tokentype_EE, Tokentype_NOTEQUALS, Tokentype_LESS, Tokentype_GREATER, Tokentype_LE, Tokentype_GE)))

        if res.error:
            return res.fail(InvalidSyntaxError(
                self.curr_tk.pos_start, self.curr_tk.pos_end,
                "Expected int, float, identifier, '+', '-', '(' or 'NOT'"
            ))

        return res.passed(node)

    def opr(self, func, op):
        res = ParseResult()
        left = res.store(func())
        if res.error:
            return res

        while self.curr_tk.type in op:
            op_tk = self.curr_tk
            res.store(self.advance())
            right = res.store(func())
            left = OPRNodes(left, op_tk, right)

        return res.passed(left)


class RTResult:
    def __init__(self):
        self.value = None
        self.error = None

    def store(self, res):
        if res.error:
            self.error = res.error
        return res.value

    def passed(self, value):
        self.value = value
        return self

    def fail(self, error):
        self.error = error
        return self


class Number:
    def __init__(self, value):
        self.value = value
        self.set_pos()
        self.set_context()

    def set_pos(self, pos_start=None, pos_end=None):
        self.pos_start = pos_start
        self.pos_end = pos_end
        return self

    def set_context(self, context=None):
        self.context = context
        return self

    def added_to(self, other):
        if isinstance(other, Number):
            return Number(self.value + other.value).set_context(self.context), None

    def subbed_by(self, other):
        if isinstance(other, Number):
            return Number(self.value - other.value).set_context(self.context), None

    def multed_by(self, other):
        if isinstance(other, Number):
            return Number(self.value * other.value).set_context(self.context), None

    def dived_by(self, other):
        if isinstance(other, Number):
            if other.value == 0:
                return None, RTError(
                    other.pos_start, other.pos_end,
                    'Division by zero',
                    self.context
                )

            return Number(self.value / other.value).set_context(self.context), None

    def powed_by(self, other):
        if isinstance(other, Number):
            return Number(self.value ** other.value).set_context(self.context), None

    def get_comparison_eq(self, other):
        if isinstance(other, Number):
            return Number(int(self.value == other.value)).set_context(self.context), None

    def get_comparison_ne(self, other):
        if isinstance(other, Number):
            return Number(int(self.value != other.value)).set_context(self.context), None

    def get_comparison_lt(self, other):
        if isinstance(other, Number):
            return Number(int(self.value < other.value)).set_context(self.context), None

    def get_comparison_gt(self, other):
        if isinstance(other, Number):
            return Number(int(self.value > other.value)).set_context(self.context), None

    def get_comparison_lte(self, other):
        if isinstance(other, Number):
            return Number(int(self.value <= other.value)).set_context(self.context), None

    def get_comparison_gte(self, other):
        if isinstance(other, Number):
            return Number(int(self.value >= other.value)).set_context(self.context), None

    def anded_by(self, other):
        if isinstance(other, Number):
            return Number(int(self.value and other.value)).set_context(self.context), None

    def ored_by(self, other):
        if isinstance(other, Number):
            return Number(int(self.value or other.value)).set_context(self.context), None

    def notted(self):
        return Number(1 if self.value == 0 else 0).set_context(self.context), None

    def copy(self):
        copy = Number(self.value)
        copy.set_pos(self.pos_start, self.pos_end)
        copy.set_context(self.context)
        return copy

    def __repr__(self):
        return str(self.value)


class Context:
    def __init__(self, display_name, parent=None, parent_entry_pos=None):
        self.display_name = display_name
        self.parent = parent
        self.parent_entry_pos = parent_entry_pos


class SymbolTable:
    def __init__(self):
        self.symbols = {}
        self.parent = None

    def get(self, name):
        value = self.symbols.get(name, None)
        if value is None and self.parent:
            return self.parent.get(name)
        return value

    def set(self, name, value):
        self.symbols[name] = value

    def remove(self, name):
        del self.symbols[name]


class Interpreter:
    def visit(self, node, context):
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, self.no_visit_method)
        return method(node, context)

    def no_visit_method(self, node, context):
        raise Exception(f'No visit_{type(node).__name__} method defined')

    def visit_NumberNode(self, node, context):
        return RTResult().passed(
            Number(node.tok.value).set_context(context).set_pos(node.pos_start, node.pos_end)
        )

    def visit_VarAccessNode(self, node, context):
        res = RTResult()
        var_name = node.var_name_tok.value
        value = context.symbol_table.get(var_name)

        if not value:
            return res.fail(RTError(
                node.pos_start, node.pos_end,
                f"'{var_name}' is not defined",
                context
            ))

        value = value.copy().set_pos(node.pos_start, node.pos_end)
        return res.passed(value)

    def visit_VarAssignNode(self, node, context):
        res = RTResult()
        var_name = node.var_name_tok.value
        value = res.passed(self.visit(node.value_node, context))
        if res.error:
            return res

        context.symbol_table.set(var_name, value)
        return res.passed(value)

    def visit_BinOpNode(self, node, context):
        res = RTResult()
        left = res.passed(self.visit(node.left_node, context))
        if res.error:
            return res
        right = res.passed(self.visit(node.right_node, context))
        if res.error:
            return res

        if node.op_tok.type == Tokentype_PLUS:
            result, error = left.added_to(right)
        elif node.op_tok.type == Tokentype_MINUS:
            result, error = left.subbed_by(right)
        elif node.op_tok.type == Tokentype_MUL:
            result, error = left.multed_by(right)
        elif node.op_tok.type == Tokentype_DIV:
            result, error = left.dived_by(right)
        elif node.op_tok.type == Tokentype_POW:
            result, error = left.powed_by(right)
        elif node.op_tok.type == Tokentype_EE:
            result, error = left.get_comparison_eq(right)
        elif node.op_tok.type == Tokentype_NOTEQUALS:
            result, error = left.get_comparison_ne(right)
        elif node.op_tok.type == Tokentype_LESS:
            result, error = left.get_comparison_lt(right)
        elif node.op_tok.type == Tokentype_GREATER:
            result, error = left.get_comparison_gt(right)
        elif node.op_tok.type == Tokentype_LE:
            result, error = left.get_comparison_lte(right)
        elif node.op_tok.type == Tokentype_GE:
            result, error = left.get_comparison_gte(right)
        elif node.op_tok.matches(Tokentype_KEYWORD, 'AND'):
            result, error = left.anded_by(right)
        elif node.op_tok.matches(Tokentype_KEYWORD, 'OR'):
            result, error = left.ored_by(right)

        if Error:
            return res.fail(Error)
        else:
            return res.passed(result.set_pos(node.pos_start, node.pos_end))

    def visit_UnaryOpNode(self, node, context):
        res = RTResult()
        number = res.store(self.visit(node.node, context))
        if res.error:
            return res

        error = None

        if node.op_tok.type == Tokentype_MINUS:
            number, error = number.multed_by(Number(-1))

        if error:
            return res.fail(error)
        else:
            return res.passed(number.set_pos(node.pos_start, node.pos_end))


global_symbol_table = SymbolTable()
global_symbol_table.set("NULL", Number(0))
global_symbol_table.set("FALSE", Number(0))
global_symbol_table.set("TRUE", Number(1))


# To initiate the lexical analysis process
def run(file_name, text):
    # Generate Tokens
    lexer = Lexical_Analyser(file_name, text)
    tokens, error = lexer.token_generator
    if error:
        return None, error

    # Generate AST
    parser = Parser(tokens)
    ast = parser.parse()
    if ast.error:
        return None, ast.error

    # Run program
    interpreter = Interpreter()
    context = Context('<program>')
    context.symbol_table = global_symbol_table
    result = interpreter.visit(ast.node, context)

    return result.value, result.error
    # return tokens, error


# TOKENS

# Operators
Tokentype_INTEGER = 'INTEGER'
Tokentype_FLOAT = 'FLOAT'
Tokentype_STRING = 'STRING'
Tokentype_PLUS = 'ADDITION'
Tokentype_MINUS = 'SUBTRACTION'
Tokentype_MUL = 'MULTIPLY'
Tokentype_DIV = 'DIVIDE'
Tokentype_EXPO = 'EXPONENT'
Tokentype_IDENTIFIER = 'IDENTIFIER'
Tokentype_KEYWORD = 'KEYWORD'
Tokentype_EQUALS = 'ASSIGNMENT'
Tokentype_NOTEQUALS = 'NOT-EQUALS'
Tokentype_GREATER = 'GREATER'
Tokentype_GE = 'GREATER_THAN_EQUAL'
Tokentype_LESS = 'LESS'
Tokentype_LE = 'LESS_THAN_EQUAL'
Tokentype_POW = 'POWER'

# Scope and Blocks
Tokentype_LPAREN = 'LPAREN'
Tokentype_RPAREN = 'RPAREN'
Tokentype_LSQUARE = 'LSQUARE'
Tokentype_RSQUARE = 'RSQUARE'
Tokentype_LCURLY = 'LCURLY'
Tokentype_RCURLY = 'RCURLY'

Tokentype_NEWLINE = 'NEWLINE'

Tokentype_SEMICOLON = 'SEMICOLON'
Tokentype_COMMA = 'COMMA'
Tokentype_COLON = 'COLON'

Tokentype_EOL = 'END_OF_LINE'

# Bitwise Operators
Tokentype_BITWISE_AND = 'BITWISE_AND'
Tokentype_BITWISE_OR = 'BITWISE_OR'
Tokentype_BITWISE_XOR = 'BITWISE_XOR'
Tokentype_MODULO = 'MODULO'
Tokentype_BOOLEAN = 'BOOLEAN'

# Increment and Decrement
Tokentype_INC = 'INCREMENT'
Tokentype_DRC = 'DECREMENT'
Tokentype_EE = 'EQUALS'

# Assignment Operators
Tokentype_ADD_ASSIGN = 'ADD_ASSIGNMENT'
Tokentype_MIN_ASSIGN = 'MINUS_ASSIGNMENT'
Tokentype_MUL_ASSIGN = 'MULTIPLY_ASSIGNMENT'
Tokentype_DIV_ASSIGN = 'DIVIDE_ASSIGNMENT'

# Bitwise Shift Assignment
Tokentype_LEFT_SHIFT = 'LEFT_SHIFT'
Tokentype_RIGHT_SHIFT = 'RIGHT_SHIFT'

# Logical Assignment
Tokentype_LOGICAL_AND = 'LOGICAL_AND'
Tokentype_LOGICAL_OR = 'LOGICAL_OR'

# CONSTANTS
DIGITS = '0123456789'
LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

# KEYWORDS
KEYWORDS = ['VAR', 'AND', 'OR', 'NOT', 'IF', 'ELSE', 'ELIF', 'WHILE', 'FOR', 'FUNCTION', 'RETURN', 'DEF', 'PRINT',
            'var', 'and', 'or', 'not', 'if', 'else', 'elif', 'while', 'for', 'function', 'return', 'def', 'print']
